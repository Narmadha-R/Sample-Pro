var React = require('react');
var ContactUsChild = React.createClass({
  render: function(){
    return (
      <div>
      <h3>contact page </h3>
      </div>
    )
  }
});
module.exports = ContactUsChild;
