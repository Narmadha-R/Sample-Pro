var React = require('react');
var AboutUsChild = React.createClass({
  render: function(){
    return (
      <div >
      <h3>About Page</h3>
      </div>
    )
  }
});
module.exports = AboutUsChild;
